drop table cdw_TIME;
create table cdw_TIME
( TIMEID VARCHAR(8), DAY INT, MONTH INT,
 QUARTER VARCHAR(8), YEAR INT)
row format delimited fields terminated by '\t'
STORED AS TEXTFILE
Tblproperties("skip.header.line.count"="3");

LOAD DATA INPATH '/user/maria_dev/Credit_card_System/CDW_SAPP_TIME/'
OVERWRITE INTO TABLE cdw_TIME;

drop table CDW_SAPP_D_TIME; 
create external table CDW_SAPP_D_TIME 
( TIMEID VARCHAR(8), DAY INT, MONTH INT,
  YEAR INT)
 PARTITIONED BY (QUARTER VARCHAR(8))
row format delimited fields terminated by ',' 
LINES TERMINATED BY '\n'
location '/user/maria_dev/Credit_card_System/CDW_SAPP_D_TIME/';

SET hive.exec.dynamic.partition=true;
SET hive.exec.dynamic.partition.mode=nonstrict;
INSERT OVERWRITE TABLE CDW_SAPP_D_TIME
PARTITION (QUARTER)
SELECT TIMEID, DAY, MONTH,
  YEAR, QUARTER
FROM cdw_TIME;
