drop table cdw_CREDITCARD;
create table cdw_creditcard
(  TRANSACTION_ID INT, CUST_CC_NO STRING, TIMEID VARCHAR(8),
  CUST_SSN INT,BRANCH_CODE INT, TRANSACTION_TYPE VARCHAR(30),
  TRANSACTION_VALUE DECIMAL(20,3))
row format delimited fields terminated by '\t'
STORED AS TEXTFILE
Tblproperties("skip.header.line.count"="3");

LOAD DATA INPATH '/user/maria_dev/Credit_card_System/CDW_SAPP_CREDITCARD'
OVERWRITE INTO TABLE cdw_creditcard;

drop table CDW_SAPP_F_CREDIT_CARD; 
create external table CDW_SAPP_F_CREDIT_CARD 
( TRANSACTION_ID INT, CUST_CC_NO STRING,CUST_SSN INT,
  BRANCH_CODE INT,TRANSACTION_TYPE VARCHAR(30), 
  TRANSACTION_VALUE DECIMAL(20,3), TIMEID VARCHAR(8))
 PARTITIONED BY (YEAR VARCHAR(4))
row format delimited fields terminated by ',' 
LINES TERMINATED BY '\n'
location '/user/maria_dev/Credit_card_System/CDW_SAPP_F_CREDIT_CARD/';
SET hive.exec.dynamic.partition=true;
SET hive.exec.dynamic.partition.mode=nonstrict;
INSERT OVERWRITE TABLE CDW_SAPP_F_CREDIT_CARD
PARTITION (YEAR)
SELECT TRANSACTION_ID, CUST_CC_NO, CUST_SSN,
  BRANCH_CODE ,TRANSACTION_TYPE , 
  TRANSACTION_VALUE , TIMEID,SUBSTRING(TIMEID,1,4) AS YEAR
FROM cdw_creditcard;
