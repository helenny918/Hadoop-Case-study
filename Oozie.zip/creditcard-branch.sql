drop table cdw_branch;
create table cdw_branch
(  BRANCH_CODE INT,BRANCH_NAME VARCHAR(25), BRANCH_STREET VARCHAR(30), 
 BRANCH_CITY VARCHAR(30), BRANCH_STATE VARCHAR(30), BRANCH_ZIP INT, 
 BRANCH_PHONE VARCHAR(13), LAST_UPDATED TIMESTAMP )
row format delimited fields terminated by ','
STORED AS TEXTFILE
Tblproperties("skip.header.line.count"="3");

LOAD DATA INPATH '/user/maria_dev/Credit_card_System/CDW_SAPP_BRANCH/part-m-00000'
OVERWRITE INTO TABLE cdw_branch;

drop table CDW_SAPP_D_BRANCH; 
create external table CDW_SAPP_D_BRANCH 
(BRANCH_CODE INT,BRANCH_NAME VARCHAR(25), BRANCH_STREET VARCHAR(30), 
 BRANCH_CITY VARCHAR(30), BRANCH_STATE VARCHAR(30), BRANCH_ZIP INT, 
 BRANCH_PHONE VARCHAR(13))
 PARTITIONED BY (LAST_UPDATED TIMESTAMP)
row format delimited fields terminated by ',' 
LINES TERMINATED BY '\n'
location '/user/maria_dev/Credit_card_System/CDW_SAPP_BRANCH/';
SET hive.exec.dynamic.partition=true;
SET hive.exec.dynamic.partition.mode=nonstrict;
INSERT OVERWRITE TABLE CDW_SAPP_D_BRANCH
PARTITION(LAST_UPDATED)
SELECT BRANCH_CODE,BRANCH_NAME, BRANCH_STREET, BRANCH_CITY, BRANCH_STATE, 
COALESCE(BRANCH_ZIP,99999),concat('(',substring(branch_phone,1,3),')',
					 substring(branch_phone,4,3),'-',substring(branch_phone,7,4)),
last_updated
FROM cdw_branch;

