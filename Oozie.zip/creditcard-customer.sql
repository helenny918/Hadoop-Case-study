DROP TABLE cdw_CUSTOMER;
create table cdw_customer 
( CUST_F_NAME VARCHAR(40), CUST_M_NAME VARCHAR(40), CUST_L_NAME VARCHAR(40), 
 CUST_SSN INT,CUST_CC_NO STRING,CUST_APT_NO STRING, CUSTO_STREET VARCHAR(38),
 CUST_CITY VARCHAR(30), CUST_STATE VARCHAR(30), CUST_COUNTRY VARCHAR(30), 
 CUST_ZIP INT, CUST_PHONE VARCHAR(8), CUST_EMAIL VARCHAR(40), LAST_UPDATED TIMESTAMP )
row format delimited fields terminated by ','
STORED AS TEXTFILE
Tblproperties("skip.header.line.count"="3");

LOAD DATA INPATH '/user/maria_dev/Credit_card_System/CDW_SAPP_CUSTOMER/part-m-00000'
OVERWRITE INTO TABLE cdw_customer;

drop table CDW_SAPP_D_CUSTOMER; 
create external table CDW_SAPP_D_CUSTOMER 
( CUST_F_NAME VARCHAR(40), CUST_M_NAME VARCHAR(40), CUST_L_NAME VARCHAR(40), 
 CUST_SSN INT,CUST_CC_NO STRING, CUSTO_STREET VARCHAR(38), CUST_CITY VARCHAR(30), 
 CUST_COUNTRY VARCHAR(30), CUST_ZIP INT, CUST_PHONE VARCHAR(8), 
 CUST_EMAIL VARCHAR(40), LAST_UPDATED TIMESTAMP )
 PARTITIONED BY (CUST_STATE VARCHAR(30))
row format delimited fields terminated by ',' 
LINES TERMINATED BY '\n'
location '/user/maria_dev/Credit_card_System/CDW_SAPP_CUSTOMER/';
SET hive.exec.dynamic.partition=true;
SET hive.exec.dynamic.partition.mode=nonstrict;
INSERT OVERWRITE TABLE CDW_SAPP_D_CUSTOMER
PARTITION (cust_state)
SELECT CONCAT(UCASE(SUBSTRING(cust_f_name, 1, 1)),LOWER(SUBSTRING(cust_f_name, 2))), 
lcase(CUST_M_NAME), 
CONCAT(UCASE(SUBSTRING(cust_l_name, 1, 1)),LOWER(SUBSTRING(cust_l_name, 2))),
cust_cc_no, concat(cust_apt_no," ",custo_street) as cust_street, cust_city, 
cust_ssn, cust_country,cust_zip, 
concat(SUBSTRING(cust_phone, 1, 3),'-',SUBSTRING(cust_phone, 4, 4)),
cust_email, last_updated, cust_state
FROM CDW_CUSTOMER;
