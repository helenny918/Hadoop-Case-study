drop table cdw_branch;
create table cdw_branch
(  BRANCH_CODE INT,BRANCH_NAME VARCHAR(25), BRANCH_STREET VARCHAR(30), 
 BRANCH_CITY VARCHAR(30), BRANCH_STATE VARCHAR(30), BRANCH_ZIP INT, 
 BRANCH_PHONE VARCHAR(13), LAST_UPDATED TIMESTAMP )
row format delimited fields terminated by ','
STORED AS TEXTFILE
Tblproperties("skip.header.line.count"="3");

LOAD DATA INPATH '/user/maria_dev/Credit_card_System/CDW_SAPP_BRANCH/part-m-00000'
OVERWRITE INTO TABLE cdw_branch;

drop table CDW_SAPP_D_BRANCH; 
create external table CDW_SAPP_D_BRANCH 
(BRANCH_CODE INT,BRANCH_NAME VARCHAR(25), BRANCH_STREET VARCHAR(30), 
 BRANCH_CITY VARCHAR(30), BRANCH_STATE VARCHAR(30), BRANCH_ZIP INT, 
 BRANCH_PHONE VARCHAR(13))
 PARTITIONED BY (LAST_UPDATED TIMESTAMP)
row format delimited fields terminated by ',' 
LINES TERMINATED BY '\n'
location '/user/maria_dev/credit_card_system/CDW_SAPP_D_BRANCH/';
SET hive.exec.dynamic.partition=true;
SET hive.exec.dynamic.partition.mode=nonstrict;
INSERT OVERWRITE TABLE CDW_SAPP_D_BRANCH
PARTITION(LAST_UPDATED)
SELECT BRANCH_CODE,BRANCH_NAME, BRANCH_STREET, BRANCH_CITY, BRANCH_STATE, 
COALESCE(BRANCH_ZIP,99999),concat('(',substring(branch_phone,1,3),')',
					 substring(branch_phone,4,3),'-',substring(branch_phone,7,4)),
last_updated
FROM cdw_branch;

drop table cdw_CREDITCARD;
create table cdw_creditcard
(  TRANSACTION_ID INT, DAY INT, MONTH INT, YEAR INT,
  CREDIT_CARD_NO VARCHAR(16), CUST_SSN INT,BRANCH_CODE INT,
   TRANSACTION_TYPE VARCHAR(30),TRANSACTION_VALUE DECIMAL(20,3))
row format delimited fields terminated by ','
STORED AS TEXTFILE
Tblproperties("skip.header.line.count"="3");

LOAD DATA INPATH '/user/maria_dev/Credit_card_System/CDW_SAPP_CREDITCARD'
OVERWRITE INTO TABLE cdw_creditcard;

drop table CDW_SAPP_F_CREDIT_CARD; 
create external table CDW_SAPP_F_CREDIT_CARD 
( TRANSACTION_ID INT, CUST_CC_NO STRING,CUST_SSN INT,
  BRANCH_CODE INT,TRANSACTION_TYPE VARCHAR(30), 
  TRANSACTION_VALUE DECIMAL(20,3), TIMEID VARCHAR(8))
 PARTITIONED BY (YEAR VARCHAR(4))
row format delimited fields terminated by ',' 
LINES TERMINATED BY '\n'
location '/user/maria_dev/credit_card_system/CDW_SAPP_F_CREDIT_CARD/';
SET hive.exec.dynamic.partition=true;
SET hive.exec.dynamic.partition.mode=nonstrict;
INSERT OVERWRITE TABLE CDW_SAPP_F_CREDIT_CARD
PARTITION (YEAR)
SELECT TRANSACTION_ID, CREDIT_CARD_NO, CUST_SSN,
  BRANCH_CODE ,TRANSACTION_TYPE , 
  TRANSACTION_VALUE , concat(YEAR,lpad(MONTH,2,'0'),lpad(DAY,2,'0')) AS TIMEID , YEAR
FROM cdw_creditcard;

DROP TABLE cdw_CUSTOMER;
create table cdw_customer 
( CUST_F_NAME VARCHAR(40), CUST_M_NAME VARCHAR(40), CUST_L_NAME VARCHAR(40), 
 CUST_SSN INT,CUST_CC_NO STRING,CUST_APT_NO STRING, CUSTO_STREET VARCHAR(38),
 CUST_CITY VARCHAR(30), CUST_STATE VARCHAR(30), CUST_COUNTRY VARCHAR(30), 
 CUST_ZIP INT, CUST_PHONE VARCHAR(8), CUST_EMAIL VARCHAR(40), LAST_UPDATED TIMESTAMP )
row format delimited fields terminated by ','
STORED AS TEXTFILE
Tblproperties("skip.header.line.count"="3");

LOAD DATA INPATH '/user/maria_dev/Credit_card_System/CDW_SAPP_CUSTOMER/part-m-00000'
OVERWRITE INTO TABLE cdw_customer;

drop table CDW_SAPP_D_CUSTOMER; 
create external table CDW_SAPP_D_CUSTOMER 
( CUST_F_NAME VARCHAR(40), CUST_M_NAME VARCHAR(40), CUST_L_NAME VARCHAR(40), 
 CUST_SSN INT,CUST_CC_NO STRING, CUSTO_STREET VARCHAR(38), CUST_CITY VARCHAR(30), 
 CUST_COUNTRY VARCHAR(30), CUST_ZIP INT, CUST_PHONE VARCHAR(8), 
 CUST_EMAIL VARCHAR(40), LAST_UPDATED TIMESTAMP )
 PARTITIONED BY (CUST_STATE VARCHAR(30))
row format delimited fields terminated by ',' 
LINES TERMINATED BY '\n'
location '/user/maria_dev/credit_card_system/CDW_SAPP_D_CUSTOMER/';
SET hive.exec.dynamic.partition=true;
SET hive.exec.dynamic.partition.mode=nonstrict;
INSERT OVERWRITE TABLE CDW_SAPP_D_CUSTOMER
PARTITION (cust_state)
SELECT CONCAT(UCASE(SUBSTRING(cust_f_name, 1, 1)),LOWER(SUBSTRING(cust_f_name, 2))), 
lcase(CUST_M_NAME), 
CONCAT(UCASE(SUBSTRING(cust_l_name, 1, 1)),LOWER(SUBSTRING(cust_l_name, 2))),
cust_cc_no, concat(cust_apt_no," ",custo_street) as cust_street, cust_city, 
cust_ssn, cust_country,cust_zip, 
concat(SUBSTRING(cust_phone, 1, 3),'-',SUBSTRING(cust_phone, 4, 4)),
cust_email, last_updated, cust_state
FROM CDW_CUSTOMER;

drop table CDW_SAPP_D_TIME; 
create external table CDW_SAPP_D_TIME 
( TIMEID VARCHAR(8), DAY INT, MONTH INT,
  YEAR INT,QUARTER VARCHAR(8))
row format delimited fields terminated by ',' 
LINES TERMINATED BY '\n'
location '/user/maria_dev/credit_card_system/CDW_SAPP_D_TIME/';

SET hive.exec.dynamic.partition=true;
SET hive.exec.dynamic.partition.mode=nonstrict;
INSERT OVERWRITE TABLE CDW_SAPP_D_TIME
SELECT concat(YEAR,lpad(MONTH,2,'0'),lpad(DAY,2,'0')) AS TIMEID, DAY, MONTH,
  YEAR,  case month when 1 then 1 when 2 then 1 when 3 then 1 when 4 then 2
  when 5 then 2 when 6 then 2 when 7 then 3 when 8 then 3 when 9 then 3
  when 10 then 4 when 11 then 4 when 12 then 4
                    end as QUARTER
FROM cdw_creditcard;